// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAc85PUikwHtxYkkEE2PtXnLx2oHhGCG2k",
    authDomain: "psalmsdevotional.firebaseapp.com",
    projectId: "psalmsdevotional",
    storageBucket: "psalmsdevotional.firebasestorage.app",
    messagingSenderId: "884994293203",
    appId: "1:884994293203:web:a981fdb62aabb242198326"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

const loginButton = document.getElementById('loginButton');
const logoutButton = document.getElementById('logoutButton');
const googleLogin = document.getElementById('googleLogin');
const loginSection = document.getElementById('login-section');
const devotionalSection = document.getElementById('devotional-section');
const psalmTheme = document.getElementById('psalm-theme');
const psalmText = document.getElementById('psalm-text');

// Handle Google Login
googleLogin.addEventListener('click', () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider);
});

auth.onAuthStateChanged((user) => {
    if (user) {
        loginSection.style.display = 'none';
        devotionalSection.style.display = 'block';
        logoutButton.style.display = 'inline';
        displayDevotional();
    } else {
        loginSection.style.display = 'block';
        devotionalSection.style.display = 'none';
        logoutButton.style.display = 'none';
    }
});

logoutButton.addEventListener('click', () => {
    auth.signOut();
});

function displayDevotional() {
    const date = new Date();
    const startDate = new Date('2025-01-01');
    const dayNumber = Math.floor((date - startDate) / (1000 * 60 * 60 * 24));

    // Sample data for daily devotionals (in practice, fetch from a database)
    const psalms = [
        { theme: "Hymns and Songs of Praises", text: "Psalm 23:1-3 - The Lord is my shepherd, I lack nothing." },
        { theme: "Thanksgiving Psalms", text: "Psalm 100:4 - Enter his gates with thanksgiving and his courts with praise." },
        // Add more devotional text based on themes as needed
    ];

    const devotional = psalms[dayNumber % psalms.length];
    psalmTheme.innerText = devotional.theme;
    psalmText.innerText = devotional.text;
}